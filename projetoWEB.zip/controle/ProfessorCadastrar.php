<?php
require_once "modelo/Professor.php";

$jsonRecebidoBodyRequest = file_get_contents('php://input');
$obj = json_decode($jsonRecebidoBodyRequest);


if ($obj->id_prof <= 0) {
    echo json_encode([
        "cod" => 400,
        "msg" => "Dados incorretos. Por favor, forneça id_a com valor positivo"
    ]);
    exit();
}
if (!isset($obj->id_prof) || !isset($obj->nome) || !isset($obj->data_nascimento)) {
    echo json_encode([
        "cod" => 400,
        "msg" => "Dados incompletos. Por favor, forneça id_curso, nome_curso, preco_curso, anos_conclusao e id_professor."
    ]);
    exit();
}

$id_prof = $obj->id_prof;
$nome = $obj->nome;
$data_nascimento = $obj->data_nascimento;


// Sanitize input
$nome = strip_tags($nome);

$Professor = new Professor();
$Professor->setId_prof($id_prof);
$Professor->setNome($nome);
$Professor->setData_nascimento($data_nascimento);


if ($Professor->cadastrar()) {
    echo json_encode([
        "cod" => 204,
        "msg" => "Cadastrado com sucesso!!!",
        "Professor" => $Professor
    ]);
} else {
    echo json_encode([
        "cod" => 500,
        "msg" => "ERRO ao cadastrar o professor"
    ]);
}
?>
