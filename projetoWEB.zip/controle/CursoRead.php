<?php
    require_once "modelo/Curso.php";

    $curso = new Curso();
    $cursos = $curso->read();

    header("Content-Type: application/json");
    if ($cursos) {
        header("HTTP/1.1 200 OK");

        // Converter cada objeto Curso em um array
        $cursosArray = array_map(function($curso) {
            return $curso->toArray();
        }, $cursos);

            // Codificar o resultado como JSON
        echo json_encode($cursosArray, JSON_PRETTY_PRINT);
    } else {
        header("HTTP/1.1 404 Not Found");
        echo json_encode(["mensagem" => "Nenhum curso encontrado."]);
    }

?>
