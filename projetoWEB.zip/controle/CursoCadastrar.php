<?php
require_once "modelo/Curso.php";

$jsonRecebidoBodyRequest = file_get_contents('php://input');
$obj = json_decode($jsonRecebidoBodyRequest);

if ($obj->id_curso <= 0) {
    echo json_encode([
        "cod" => 400,
        "msg" => "Dados incorretos. Por favor, forneça id_a com valor positivo"
    ]);
    exit();
}

if (!isset($obj->id_curso) || !isset($obj->nome_curso) || !isset($obj->preco_curso) || !isset($obj->anos_conclusao) || !isset($obj->id_professor)) {
    echo json_encode([
        "cod" => 400,
        "msg" => "Dados incompletos. Por favor, forneça id_curso, nome_curso, preco_curso, anos_conclusao e id_professor."
    ]);
    exit();
}

$id_curso = $obj->id_curso;
$nome_curso = $obj->nome_curso;
$preco_curso = $obj->preco_curso;
$anos_conclusao = $obj->anos_conclusao;
$id_professor = $obj->id_professor;

// Sanitize input
$nome_curso = strip_tags($nome_curso);

$curso = new Curso();
$curso->setIdCurso($id_curso);
$curso->setNomeCurso($nome_curso);
$curso->setPrecoCurso($preco_curso);
$curso->setAnosConclusao($anos_conclusao);
$curso->setIdProfessor($id_professor);

if ($curso->cadastrar()) {
    echo json_encode([
        "cod" => 201,
        "msg" => "Cadastrado com sucesso!!!",
        "curso" => $curso
    ]);
} else {
    echo json_encode([
        "cod" => 500,
        "msg" => "ERRO ao cadastrar o curso"
    ]);
}
?>
