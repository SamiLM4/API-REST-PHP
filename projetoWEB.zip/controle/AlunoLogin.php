<?php
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Firebase\JWT\MeuTokenJWT;

require_once "modelo/Aluno.php";
require_once "modelo/MeuTokenJWT.php";

$jsonRecebidoBodyRequest = file_get_contents('php://input');
$obj = json_decode($jsonRecebidoBodyRequest);

if (!isset($obj->email) || !isset($obj->id_curso) || $obj->id_curso <= 0) {
    echo json_encode([
        "cod" => 400,
        "msg" => "Dados incorretos ou incompletos. Por favor, forneça email e id_curso válido."
    ]);
    exit();
}

$email = $obj->email;
$id_curso = $obj->id_curso;

$aluno = new Aluno();
$aluno->setEmail($email);
$aluno->setIdcurso($id_curso);

if ($aluno->login()) {
  
    $tokenJWT = new MeuTokenJWT();
    $objectClaimsToken = new stdClass();
    $objectClaimsToken->id_a = $aluno->getId_a();
    $objectClaimsToken->nome = $aluno->getNome();
    $objectClaimsToken->email = $aluno->getEmail();
    $objectClaimsToken->id_curso = $aluno->getIdcurso();
    $novoToken = $tokenJWT->gerarToken($objectClaimsToken);
    
    echo json_encode([
        "cod" => 200,
        "msg" => "Login realizado com sucesso!!!",
        "Aluno" => [
            "id_a" => $aluno->getId_a(),
            "nome" => $aluno->getNome(),
            "email" => $aluno->getEmail(),
            "id_curso" => $aluno->getIdcurso()
        ],
        "token" => $novoToken
    ]);
} else {
    echo json_encode([
        "cod" => 401,
        "msg" => "ERRO: Login inválido. Verifique suas credenciais."
    ]);
}
?>
