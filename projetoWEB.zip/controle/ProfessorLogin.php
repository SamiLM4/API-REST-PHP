<?php
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Firebase\JWT\MeuTokenJWT2;

require_once "modelo/Professor.php";
require_once "modelo/MeuTokenJWT2.php";

$jsonRecebidoBodyRequest = file_get_contents('php://input');
$obj = json_decode($jsonRecebidoBodyRequest);

if (!isset($obj->nome) || !isset($obj->id_prof) || $obj->id_prof <= 0) {
    echo json_encode([
        "cod" => 400,
        "msg" => "Dados incorretos ou incompletos. Por favor, forneça email e id_curso válido."
    ]);
    exit();
}

$id_prof = $obj->id_prof;
$nome= $obj->nome;

$nome = strip_tags($nome);

$professor = new Professor();
$professor->setId_prof($id_prof);
$professor->setNome($nome);


if ($professor->login()) {
  
    $tokenJWT = new MeuTokenJWT2();
    $objectClaimsToken = new stdClass();
    $objectClaimsToken->id_prof = $professor->getId_prof();
    $objectClaimsToken->nome = $professor->getNome();
    $objectClaimsToken-> data_nascimento = $professor->getData_nascimento();
    
    $novoToken = $tokenJWT->gerarToken($objectClaimsToken);
    
    echo json_encode([
        "cod" => 200,
        "msg" => "Login realizado com sucesso!!!",
        "Professor" => [
            "id_prof" => $professor->getId_prof(),
            "nome" => $professor->getNome(),
            "data_nascimento" => $professor->getData_nascimento()
           
        ],
        "token" => $novoToken
    ]);
} else {
    echo json_encode([
        "cod" => 401,
        "msg" => "ERRO: Login inválido. Verifique suas credenciais."
    ]);
}
?>
