<?php
require_once "modelo/Aluno.php";

$jsonRecebidoBodyRequest = file_get_contents('php://input');
$obj = json_decode($jsonRecebidoBodyRequest);
if ($obj->id_a <= 0) {
    echo json_encode([
        "cod" => 400,
        "msg" => "Dados incorretos. Por favor, forneça id_a com valor positivo"
    ]);
    exit();
}

if (!isset($obj->id_a) || !isset($obj->nome) || !isset($obj->email) || !isset($obj->id_curso)) {
    echo json_encode([
        "cod" => 400,
        "msg" => "Dados incompletos. Por favor, forneça id_a, nome, email, id_curso."
    ]);
    exit();
}

$id_a = $obj->id_a;
$nome = $obj->nome;
$email= $obj->email;
$id_curso = $obj->id_curso;


// Sanitize input
$nome = strip_tags($nome);

$aluno = new Aluno();
$aluno->setId_a($id_a);
$aluno->setNome($nome);
$aluno->setEmail($email);
$aluno->setIdcurso($id_curso);


if ($aluno->cadastrar()) {
    echo json_encode([
        "cod" => 201,
        "msg" => "Cadastrado com sucesso!!!",
        "Aluno" =>$aluno
    ]);
} else {
    echo json_encode([
        "cod" => 500,
        "msg" => "ERRO ao cadastrar o Aluno"
    ]);
}
?>




